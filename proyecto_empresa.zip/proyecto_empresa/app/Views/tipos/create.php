<h1>Nuevo Tipo de Producto</h1>

<form method="post" action="/tipoproducto/store">
    <label>Nombre</label>
    <input type="text" name="nombre" required>

    <label>Descripción</label>
    <input type="text" name="descripcion">

    <button type="submit">Guardar</button>
</form>
